package IParty;

import Modelos.Armazem;
import Modelos.Evento;
import Modelos.Local;


public class teste2 {
    
    public static void main(String[] args){
        
        String nome = "Choppada";
        System.out.println(nome);
        
        //Evento evento = new Evento(11, "Choppada", "role em chacara", "rua rolezera");
        
       // System.out.println(evento.getNome());
        
        Usuario usuario = new Usuario("pasalomao1@gmail.com", "senha123");
        System.out.println(usuario);
        
        Armazem armazem = new Armazem("Esquenta", "Rua123", "123456789");
        System.out.println(armazem.getNome());
        
        Local local = new Local("Chacarinha", "rua role", 250, "1233456789", "chacara para role");
        System.out.println(local.getNome());
        System.out.println(local.getCapacidadeMax());
    
    }
            
       
    
}
