package IParty;

import java.util.Date;


public class Usuario {
    
    private String nome;
    private String email;
    private String senha;
    private String telefone;
    private Date dataNasscimento;
    private String rg;
    private char sexo;
    private String endereco;

    public Usuario(String nome, String email, String senha, String telefone, String rg, String endereco) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
        this.rg = rg;
        this.endereco = endereco;
    }
    
    

    public Usuario(String nome, String email, String senha, String telefone, Date dataNasscimento, String rg, char sexo, String endereco) {
        this.nome = nome;
        this.email = email;
        this.senha = senha;
        this.telefone = telefone;
        this.dataNasscimento = dataNasscimento;
        this.rg = rg;
        this.sexo = sexo;
        this.endereco = endereco;
    }

    public Usuario(String email, String senha) {
        this.email = email;
        this.senha = senha;
    }

    public Usuario() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSenha() {
        return senha;
    }

    public void setSenha(String senha) {
        this.senha = senha;
    }
    
    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public Date getDataNasscimento() {
        return dataNasscimento;
    }

    public void setDataNasscimento(Date dataNasscimento) {
        this.dataNasscimento = dataNasscimento;
    }

    public String getRg() {
        return rg;
    }

    public void setRg(String rg) {
        this.rg = rg;
    }

    public char getSexo() {
        return sexo;
    }

    public void setSexo(char sexo) {
        this.sexo = sexo;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public void salvar(String cadastrotxt, String cadastro, boolean b) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
    
    
}
