package com.example.apolo;

public class Constants {
    private static final String ROOT_URL = "http://192.168.0.199/ApoloPHP/";
    public static final String URL_REGISTER = ROOT_URL + "createUsuario.php";
    public static final String URL_LOGIN = ROOT_URL + "loginUsuario.php";
    public static final String URL_TROCAR_SENHA = ROOT_URL + "updateSenha.php";
    public static final String URL_TROCAR_EMAIL = ROOT_URL + "updateEmail.php";
    public static final String URL_TROCAR_NOME = ROOT_URL + "updateNome.php";
}
