package com.example.apolo;

import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.TextView;

import com.google.android.material.navigation.NavigationView;

public class Home extends AppCompatActivity {

    TextView nomeGlobal, emailGlobal;
    Variaveis variaveis;
    DrawerLayout mDrawerLayout;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        variaveis = (Variaveis) getApplication();


        // Drawer
        mDrawerLayout = (DrawerLayout) findViewById(R.id.drawerLayout);
        mDrawerLayout.closeDrawers();


        // NavView
        NavigationView navigationView = findViewById(R.id.navigationView);
        View navView = navigationView.inflateHeaderView(R.layout.activity_cabecario);
        nomeGlobal = navView.findViewById(R.id.textViewNomeGlobal);
        emailGlobal = navView.findViewById(R.id.textViewEmailGlobal);
        nomeGlobal.setText(variaveis.getNomeLogado());
        emailGlobal.setText(variaveis.getEmailLogado());



    }

    public void onResume(){
        nomeGlobal.setText(variaveis.getNomeLogado());
        emailGlobal.setText(variaveis.getEmailLogado());
        super.onResume();
    }

    public void irConfigUsuario(MenuItem item){
        Intent it = new Intent(this, PerfilUsuario.class);
        startActivity(it);

        mDrawerLayout.closeDrawers();
    }
    public void criarEvento(MenuItem item){
        Intent it = new Intent(this, CriarEventos.class);
        startActivity(it);

        mDrawerLayout.closeDrawers();
    }
    public void simulador(MenuItem item){
        Intent it = new Intent(this, Simulador.class);
        startActivity(it);

        mDrawerLayout.closeDrawers();
    }
    public void irArmazem(MenuItem item){
        Intent it = new Intent(this, Armazen.class);
        startActivity(it);

        mDrawerLayout.closeDrawers();
    }
    public void irChacara(MenuItem item){
        Intent it = new Intent(this, Chacara.class);
        startActivity(it);

        mDrawerLayout.closeDrawers();
    }
}