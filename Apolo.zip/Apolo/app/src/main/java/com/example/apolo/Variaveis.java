package com.example.apolo;

import android.app.Application;

public class Variaveis extends Application{
    private String nomeLogado;
    private String emailLogado;
    private String idLogado;

    public String getNomeLogado() {
        return nomeLogado;
    }

    public void setNomeLogado(String nomeLogado) {
        this.nomeLogado = nomeLogado;
    }

    public String getEmailLogado() {
        return emailLogado;
    }

    public void setEmailLogado(String emailLogado) {
        this.emailLogado = emailLogado;
    }

    public String getIdLogado() {
        return idLogado;
    }

    public void setIdLogado(String idLogado) {
        this.idLogado = idLogado;
    }
}
