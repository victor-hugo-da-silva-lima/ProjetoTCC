package com.example.apolo;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Login extends AppCompatActivity {
    private EditText editTextSenha, editTextEmail;
    Variaveis variaveis;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        editTextEmail = findViewById(R.id.editTextEmailCadastro);
        editTextSenha = findViewById(R.id.editTextNomeCadastro);

        variaveis = (Variaveis)getApplication();
    }
    public void loginUsuario(View view){
        StringRequest stringRequest = new StringRequest(
                Request.Method.POST,
                Constants.URL_LOGIN,
                new Response.Listener<String>() {
                    @Override
                    public void onResponse(String response) {
                        try {

                            JSONObject obj = new JSONObject(response);
                            if (!obj.getBoolean("erro")){
                                variaveis.setEmailLogado(obj.getString("email"));
                                variaveis.setNomeLogado(obj.getString("nome"));
                                variaveis.setIdLogado(obj.getString("idUsuario"));
                                Toast.makeText(getApplicationContext(), "Logado : " + variaveis.getEmailLogado() + " " + variaveis.getIdLogado(), Toast.LENGTH_SHORT).show();
                                irPrincipal();
                            } else {
                                Toast.makeText(getApplicationContext(), obj.getString("mensagem"), Toast.LENGTH_SHORT).show();
                        }
                        } catch (JSONException e) {
                            e.printStackTrace();
                        }
                    }
                }, new Response.ErrorListener() {
            @Override
            public void onErrorResponse(VolleyError error) {
                Toast.makeText(getApplicationContext(), error.getMessage(), Toast.LENGTH_SHORT).show();
            }
        }
        ){
            @Override
            protected Map<String, String> getParams() throws AuthFailureError {
                Map<String, String> params = new HashMap<>();
                params.put("email", editTextEmail.getText().toString());
                params.put("senha", editTextSenha.getText().toString());
                return params;
            }
        };
        RequestQueue requestQueue = Volley.newRequestQueue(this);
        requestQueue.add(stringRequest);
    }

    public void irCadastro(View view) {
        Intent it = new Intent(this, Cadastro.class);
        startActivity(it);
    }

    private void irPrincipal(){
        Intent it = new Intent(getApplicationContext(), Home.class);
        startActivity(it);
    }

}




