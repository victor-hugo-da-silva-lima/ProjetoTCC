package com.example.apolo;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class CriarEventos extends AppCompatActivity {
    private EditText nomeEvento, preco, local, descricao, data;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_criar_eventos);

        nomeEvento = findViewById(R.id.editTextNomeEvento);
        preco = findViewById(R.id.editTextPrecoEvento);
        local = findViewById(R.id.editTextLocalEvento);
        descricao = findViewById(R.id.editTextDescricaoEvento);
        data = findViewById(R.id.editTextDataEvento);
    }
    public void criarEvento(View view){
        if (nomeEvento.getText().toString().equals("")) {
            Toast.makeText(this, "Senhas incompativeis.", Toast.LENGTH_SHORT).show();
        } else {
            StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_REGISTER, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        Toast.makeText(CriarEventos.this, jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                        if (jsonObject.getString("erro").equals("false")) {
                            finish();
                        }

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            },
                    new Response.ErrorListener() {
                        @Override
                        public void onErrorResponse(VolleyError error) {
                            Toast.makeText(CriarEventos.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    })
                    {
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<>();
                    params.put("nome", nomeEvento.getText().toString().trim());
                    params.put("preco", preco.getText().toString().trim());
                    params.put("local", local.getText().toString().trim());
                    params.put("descricao", descricao.getText().toString().trim());
                    params.put("data", data.getText().toString().trim());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        }
    }

    public void voltarHome(View view) {
        Intent it = new Intent(this, Home.class);
        startActivity(it);
    }
}
