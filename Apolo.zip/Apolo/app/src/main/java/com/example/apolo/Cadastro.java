package com.example.apolo;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.android.volley.AuthFailureError;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class Cadastro extends AppCompatActivity {
    private EditText email, senha, senha2, nome, CEP, RG;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastro);

        email = findViewById(R.id.editTextEmailCadastro);
        nome = findViewById(R.id.editTextNomeCadastro);
        senha = findViewById(R.id.editTextSenhaCadastro);
        senha2 = findViewById(R.id.editTextSenha2);
        CEP = findViewById(R.id.editCEP);
        RG = findViewById(R.id.editRG);
    }
    public void cadastrarUsuario(View view){
        if (senha.getText().toString().equals(senha2.getText().toString())) {
             StringRequest stringRequest = new StringRequest(Request.Method.POST, Constants.URL_REGISTER, new Response.Listener<String>() {
                @Override
                public void onResponse(String response) {
                    try {
                        JSONObject jsonObject = new JSONObject(response);
                        Toast.makeText(Cadastro.this, jsonObject.getString("mensagem"), Toast.LENGTH_SHORT).show();
                        if (jsonObject.getString("erro").equals("false")) {finish();}

                    } catch (JSONException e) {
                        e.printStackTrace();
                    }

                }
            },  new Response.ErrorListener() {
                @Override
                public void onErrorResponse(VolleyError error) {
                    Toast.makeText(Cadastro.this, error.getMessage(), Toast.LENGTH_SHORT).show();
                }
            }){
                @Override
                protected Map<String, String> getParams() throws AuthFailureError {
                    Map<String,String> params = new HashMap<>();
                    params.put("email", email.getText().toString().trim());
                    params.put("nome", nome.getText().toString().trim());
                    params.put("senha", senha.getText().toString().trim());
                    params.put("rg", RG.getText().toString().trim());
                    params.put("cep", CEP.getText().toString().trim());
                    return params;
                }
            };
            RequestQueue requestQueue = Volley.newRequestQueue(this);
            requestQueue.add(stringRequest);
        } else {
            Toast.makeText(this, "Senhas incompativeis.", Toast.LENGTH_SHORT).show();
        }
    }

    public void voltar(View view) {
        finish();
    }
}