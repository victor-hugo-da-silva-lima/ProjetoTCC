package util;

import javax.swing.JDesktopPane;
import javax.swing.JInternalFrame;

public class Gerente_JInternalFrames {
    
    private static JDesktopPane jDesktopPane1;
    
    public Gerente_JInternalFrames (JDesktopPane jDesktopPane){
        Gerente_JInternalFrames.jDesktopPane1 = jDesktopPane;
    }
    
    public void abrirJInternalFrames(JInternalFrame jInternalFrame){
        if(jInternalFrame.isVisible()){
            jInternalFrame.toFront();
            jInternalFrame.requestFocus();
        } else{
            jDesktopPane1.add(jInternalFrame);
            jInternalFrame.setVisible(true);
        }
    }
}
