package Modelos;

import java.util.Date;


public class Evento {
    
    private int idEvento;
    private String nome;
    private Date data;
    private String lote;
    private Local local;
    private String descricao;

    public Evento(int idEvento, String nome, Date data, String lote, Local local, String descricao) {
        this.idEvento = idEvento;
        this.nome = nome;
        this.data = data;
        this.lote = lote;
        this.local = local;
        this.descricao = descricao;
    }

    public Evento(int idEvento, String nome, Date data, String lote, String descricao) {
        this.idEvento = idEvento;
        this.nome = nome;
        this.data = data;
        this.lote = lote;
        this.descricao = descricao;
    }

    public int getIdEvento() {
        return idEvento;
    }

    public void setIdEvento(int idEvento) {
        this.idEvento = idEvento;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public Date getData() {
        return data;
    }

    public void setData(Date data) {
        this.data = data;
    }

    public String getLote() {
        return lote;
    }

    public void setLote(String lote) {
        this.lote = lote;
    }

    public Local getLocal() {
        return local;
    }

    public void setLocal(Local local) {
        this.local = local;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
   

    
}
