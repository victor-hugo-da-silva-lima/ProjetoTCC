<? php 

if (! isset ( $ _SESSION [ 'carrinho' ]))) {
	$ _SESSION [ 'carrinho' ] = array ();
}

função  addCart ( $ id , $ Quantity ) {
	if (! isset ( $ _SESSION [ 'carrinho' ] [ $ id ])) {
		$ _SESSION [ 'carrinho' ] [ $ id ] = $ quantidade ;
	}
}

função  deleteCart ( $ id ) {
	if ( isset ( $ _SESSION [ 'carrinho' ] [ $ id ])) {
		não definido ( $ _SESSION [ 'carrinho' ] [ $ id ]);
	} 
}

função  updateCart ( $ id , $ Quantity ) {
	if ( isset ( $ _SESSION [ 'carrinho' ] [ $ id ])) {
		if ( $ Quantity > 0 ) {
			$ _SESSION [ 'carrinho' ] [ $ id ] = $ quantidade ;
		} mais {
		 	deleteCart ( $ id );
		}
	}
}

função  getContentCart ( $ pdo ) {
	
	$ resultados = matriz ();
	
	if ( $ _SESSION [ 'carrinho' ]) {
		
		$ carrinho = $ _SESSION [ 'carrinho' ];
		$ produtos =   getProductsByIds ( $ pdo , implode ( ',' , array_keys ( $ carrinho )));

		foreach ( $ produtos  como  $ produto ) {

			$ resultados [] = matriz (
							  'id' => $ product [ 'id' ],
							  'name' => $ product [ 'nome' ],
							  'price' => $ product [ 'preco' ],
							  'quantidade' => $ carrinho [ $ produto [ 'id' ]],
							  'subtotal' => $ cart [ $ product [ 'id' ]] * $ product [ 'preco' ],
						);
		}
	}
	
	retornar  $ resultados ;
}

função  getTotalCart ( $ pdo ) {
	
	$ total = 0 ;

	foreach ( getContentCart ( $ pdo ) como  $ product ) {
		$ total + = $ produto [ 'subtotal' ];
	} 
	retornar  $ total ;
}