<html>
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
    </head>    
    <body>
        <form method="get">
            Login:<br>
            <input type="text" name="login">

            <br><br>

            Senha:<br>
            <input type="password" name="senha">

            <br><br>

            <input type="submit" value="validar!">

            <br><br>

        </form>
    </body>
</html>

<?php
if ($_SERVER["REQUEST_METHOD"] === 'GET') {

    if (isset($_GET["senha"]) and isset($_GET["login"])){
        $senha = htmlspecialchars($_GET["senha"]);
        $login = htmlspecialchars($_GET["login"]);

        if ($senha == '123' and $login == 'victor') {
            session_start();
            
            $_SESSION["login"] = $login;
            $_SESSION["senha"] = $senha;

            header("location:home.php");

           
        } else {
            echo "login invalido";
        }
       
    }
}
?>

