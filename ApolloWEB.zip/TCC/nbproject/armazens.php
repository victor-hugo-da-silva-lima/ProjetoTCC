<html>
<head> 
<?php
           include("navBar.php");  
           session_start();
        ?>
           
    <script src="https://kit.fontawesome.com/c488a94340.js"></script>
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="tcc.CSS">
	<title>IParty</title>
  </head>
    <body>
        
        <br><br>
<br>
<div class="row" style="width: ">
  <div class="col-sm-6">
    <div class="card">
    <img src="imagens//armazem1.jpg">
      <div class="card-body">
        <h5 class="card-title">Esquenta</h5>
        <p class="card-text">preços sempre baixos e venda de bebidas para maiores.</p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
   Local
  </a>
</p>
<div class="collapse" id="collapseExample">
  <div class="card card-body">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.689660444053!2d-46.563146685243915!3d-23.54366188469167!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce5f8cfb8b0e8d%3A0xc282a85b6f96dd8d!2sCalifa%20Brewpub!5e0!3m2!1spt-BR!2sbr!4v1567689894831!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
  </div>
</div></a>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
    	<img src="imagens//armazem2.jpeg">
      <div class="card-body">
        <h5 class="card-title">Brexó</h5>
        <p class="card-text">Bebidas de alta qualidade além de tratarmos nossos clientes da melhor forma</p>
        <p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExamplee" role="button" aria-expanded="false" aria-controls="collapseExamplee">
    Local
  </a>
  
</p>
<div class="collapse" id="collapseExamplee">
  <div class="card card-body">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3675.403390636119!2d-47.05164818525707!3d-22.898487485016055!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8cf4f9e991391%3A0x52a1d58bae9fcd34!2sBrex%C3%B3%20Bar%20e%20Cozinha%20Campinas!5e0!3m2!1spt-BR!2sbr!4v1567689958734!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
  </div>
</div>
      </div>
    </div>
  </div>
</div>
</div>
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>