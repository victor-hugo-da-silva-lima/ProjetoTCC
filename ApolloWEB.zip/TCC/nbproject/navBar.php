<html>
    <head>
        <title>APOLO</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <script src="https://kit.fontawesome.com/c488a94340.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
        <style type="text/css">
          
           .nav-link{
            color: #848484;
          }
          .navbar-brand{
            color: #848484;
          }
        </style>
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="tcc.CSS">
	<title>Apolo</title>
    </head>
    <body>
        
        
        <nav  class="navbar fixed-top navbar-expand-lg navbar-light shadow bg-white ">
  <a class="navbar-brand" href="" style="margin-top: 5px;">
  	<img src="AreaEfetivada/logo_sizeP.jpg" style="" sizes="30px" width="50px" class="rounded-circle"> Apolo</a>
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menuSanduba" >
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="menuSanduba">
    <ul class="navbar-nav mr-auto">
     <li class="nav-item active"></li>
      <li class="nav-item active">
        <a class="nav-link" href="#Evento" id="home" style="margin-top: 2px;" ><i class="fas fa-home" style="color: lightgray;"></i> Home<span class="sr-only">(current)</span></a>
      </li>
     
      
      
     
     
      
    </ul>
     
    <form class="form-inline my-2 my-lg-0">
      <div class="input-group">
        <div class="input-group-prepend">
         
     <ul class="navbar-nav mr-auto">
        <li class="nav-item active">
        <a  class="btn btn-info my-2 my-sm-0" href="Login/index.php">Faça seu Login</a>
       </li>
     </ul>
    </form>

   
</nav>
        
        
        
    </body>
</html>