<html>
<head>
    <?php
           include("navBar.php");  
           session_start();
        ?>
           
    <script src="https://kit.fontawesome.com/c488a94340.js"></script>
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<link rel="stylesheet" type="text/css" href="tcc.CSS">
	<title>IParty</title>
</head>


<body>
    
<br><br>
<br>
<div class="row" style="width: ">
  <div class="col-sm-6">
    <div class="card">
    <img src="imagens//chacaraa1.jpg">
      <div class="card-body">
        <h5 class="card-title">Chácara do Vinna</h5>
        <p class="card-text">Essa chacara é bem tratada e aconchegante.</p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExample" role="button" aria-expanded="false" aria-controls="collapseExample">
   Local
  </a>

<div class="collapse" id="collapseExample">
  <div class="card card-body">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3678.0139969729144!2d-47.05428088499485!3d-22.801945239871035!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8c13911d81bc1%3A0x72082402e2354f6c!2sChacara%20do%20Vina!5e0!3m2!1spt-BR!2sbr!4v1567684182241!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
  </div>
</div>
      </div>
    </div>
  </div>
  <div class="col-sm-6">
    <div class="card">
    	<img src="imagens//chacaraa2.jpg">
      <div class="card-body">
        <h5 class="card-title">Chácara da Paula</h5>
        <p class="card-text">Essa chácara é bem requisitada e orgaizada conforme as ordens</p>
        <p>
  <a class="btn btn-primary" data-toggle="collapse" href="#collapseExamplee" role="button" aria-expanded="false" aria-controls="collapseExamplee">
   local
  </a>
  
</p>
<div class="collapse" id="collapseExamplee">
  <div class="card card-body">
    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3684.446414946684!2d-47.42730148500023!3d-22.56240103134514!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94c8806c2c324933%3A0xe2108428886c8646!2sCotil%20(Unicamp)!5e0!3m2!1spt-BR!2sbr!4v1567683969112!5m2!1spt-BR!2sbr" width="600" height="450" frameborder="0" style="border:0;" allowfullscreen=""></iframe>
  </div>
</div>
      </div>
    </div>
  </div>
</div>

          <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>