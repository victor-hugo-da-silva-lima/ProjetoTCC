<html>
    <head>
         <?php
           include("navBar.php");  
           session_start();
               ?>
        


 <?php
if (!isset($_SESSION["login"]))
    {
       echo "<span style='color:red;font-weight: bold';>Acesso não autorizado!</span>
            <br><br>
            <a href='login.php'>Login</a>";


    }
    
  else
  {     
     
       echo "Seja bem vindo ao seu perfil " . $_SESSION['login'];                         
  }
    
        ?>
        
            
    </body>
</html>



