<?php 

  require_once 'usuarios.php';
  $u = new Usuario;
 ?>


<!DOCTYPE html>
<html>

<script type="text/javascript">
function formatar_mascara(src, mascara) {
 var campo = src.value.length;
 var saida = mascara.substring(0,1);
 var texto = mascara.substring(campo);
 if(texto.substring(0,1) != saida) {
 src.value += texto.substring(0,1);
 }
}
</script>
<head>
	<title>Cadastro</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo1.css">
    <link rel="icon" type="image/png" href="../AreaEfetivada/font (2).png">
</head>
<body>
	<div id="corpo">
	<h1>Cadastro</h1>
  <form method="POST">
 <input type="text" name="nome" placeholder="Nome Completo" maxlength="30">
 <input type="email" name="email" placeholder="Email" maxlength="40">
 <input type="password" name="senha" placeholder="Senha" maxlength="15">
 <input type="password" name="confiSenha" placeholder="Confirmar senha" maxlength="15">
 <input type="text" name="rg" placeholder="CPF" min="9" max="12">
 <!--<script type="text/javascript" src="https://code.jquery.com/jquery-3.2.1.min.js"></script>-->

<!--Formulário-->
<form>

		<input id="cep" type="text" name="sexo" required placeholder="Sexo( M ou F)" maxlength="1" />

        <input id="cep" type="text" name="dataNasc" required placeholder="Data nascimento" onkeypress="formatar_mascara(this,'##/##/####')"/>

		<input id="logradouro" name="rua" type="text" required placeholder="Rua" maxlength="55" />
		<input id="bairro" type="text" name="bairro" required placeholder="Bairro" maxlength="30" />
		<input type="text" name="estado" required placeholder="Estado" maxlength="30">
        <input type="text" name="numero" required placeholder="Numero do local" maxlength="45">
        <input type="text" name="telefone" required placeholder="Telefone" maxlength="45">
       
  
 

 <input type="submit" value="Cadastrar">
  </form>
</div>  
<br><br>
<?php 
if(isset($_POST['nome']))
{
	$nome=(($_POST['nome']));
	$email=(($_POST['email']));
	$senha=(($_POST['senha']));
	$confiSenha=(($_POST['confiSenha']));
	$RG=(($_POST['rg']));
	$sexo=(($_POST['sexo']));
    $dataNasc=(($_POST['dataNasc']));
	$rua=(($_POST['rua']));
	$bairro=(($_POST['bairro']));
	$estado=(($_POST['estado']));
    $numero=(($_POST['numero']));
    $telefone=(($_POST['telefone']));
 
    if(!empty($nome) && !empty($email) && !empty($senha)&& !empty($confiSenha)&& !empty($RG)&& !empty($sexo)&& !empty($dataNasc)&& !empty($rua)&& !empty($bairro)&& !empty($estado) && !empty($numero) && !empty($telefone))
    {
       
     $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");
    
     	
     if($u->msgErro=="")//se esta ok
     {
     	if ($senha==$confiSenha)
     	 {

     		  if($u->cadastrar($nome,$email,$senha,$RG,$sexo,$dataNasc,$rua,$bairro,$estado,$numero,$telefone))
     		  {    
     		  	   ?>
     		  	   <div id="msgSucesso">
                   Cadastrado com sucesso! Volte ao<a href="index.php" style="text-decoration: none;"><strong><span style="color: white;"> login </span></strong></a>e acesse!
               </div>
                   <?php 
     		  }
     		  else
     		  {
     		  	?>
     		  	<div class="msg-erro">
     		  	Email ja cadastrado!
     		  </div>
     		  	<?php
     		  }
     	 }
     	 else{
     	 	?>
     	 	<div class="msg-erro">
     	 	Senha e confirmar senha não correspondem
     	   </div>
     	 <?php
     	 }
        
     }
     else{
     	echo "Erro: ".$u->msgErro;
     }

    }
    else
    {    
    	?>
    	<div class="msg-erro">
    	Preencha todos os campos
    </div>
    <?php
    }
}


 ?>   
</body>
</html>
