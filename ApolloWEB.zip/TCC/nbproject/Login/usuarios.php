<?php 
Class Usuario
{

 private $pdo;
 public $msgErro="";
 public function conectar($nome, $host, $usuario, $senha)
 {
   global $pdo;
   global $msgErro;
   try {
   	$pdo= new PDO("mysql:dbname=".$nome.";host=".$host,$usuario,$senha);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
   } 
   catch (PDOException $e) {
   	$msgErro=$e->getMessage();
   }
   catch(Exception $e){
         
   }

 }
  
 public function cadastrar($nome,$email,$senha,$RG,$sexo,$dataNasc,$rua,$bairro,$estado,$numero,$telefone)
  {

   global $pdo;
   global $msgErro;
 
    // verificar se já existe
    $sql=$pdo->prepare("SELECT id_usuario FROM usuarios WHERE email= :em");
    
    $sql->bindValue(":em",$email);
    $sql->execute();
    if($sql->rowCount() > 0)
    {
    
    	return false; //ja esta cadastrada

    }
    else{
               // cadastrar 
    	$sql= $pdo->prepare("INSERT INTO usuarios (nome,email,senha,RG,sexo,dataNasc,rua,bairro,estado,numero,telefone) VALUES (:n, :em, :s, :r, :sex, :dat, :ru, :b, :es, :num, :tel)");

        $sql->bindValue(":n",$nome);
        $sql->bindValue(":em",$email);
        $sql->bindValue(":s",md5($senha));
        $sql->bindValue(":r",$RG);
        $sql->bindValue(":sex",$sexo);
        $sql->bindValue(":dat",$dataNasc);
        $sql->bindValue(":ru",$rua);
        $sql->bindValue(":b",$bairro);
        $sql->bindValue(":es",$estado);
        $sql->bindValue(":num",$numero);
        $sql->bindValue(":tel",$telefone);


        $sql->execute();
         return true;

    }
         
  }

 public function logar($email,$senha)
 {
    global $pdo;
    global $msgErro;

    $sql=$pdo->prepare("SELECT id_usuario FROM usuarios WHERE email= :em AND senha= :s");

    $sql->bindValue(":em",$email);
    $sql->bindValue(":s",md5($senha));
  
    $sql->execute();

    if ($sql->rowCount()>0)
     {
    	//entrar no sistema
     
    	$dado= $sql->fetch();
    	session_start();
    	$_SESSION['id_usuario'] = $dado['id_usuario'];
      $_SESSION['email']=$email;
 

      

     return true; //login feito com sucesso
     }
     else
     {
         return false;
     }
    
 }


    /*public function perfil($nome,$email,$senha,$RG,$CEP,$rua,$bairro,$estado){
        global $pdo;
    global $msgErro;

     $sql= $pdo->prepare("SELECT id_usuario  FROM usuarios WHERE email= :em AND senha= :s AND RG=:r AND CEP=:c AND rua=:ru AND bairro=:b AND estado=:es");
      $sql->bindValue(":n",$nome);
        $sql->bindValue(":em",$email);
        $sql->bindValue(":s",md5($senha));
        $sql->bindValue(":r",$RG);
        $sql->bindValue(":c",$CEP);
        $sql->bindValue(":ru",$rua);
        $sql->bindValue(":b",$bairro);
        $sql->bindValue(":es",$estado);
        $sql->execute();

        if($sql->rowCount() > 0)
    {
      
     session_start();
     $_SESSION['nome'] =$nome;
     $_SESSION['email'] =$email;
     $_SESSION['senha'] =$senha;
     $_SESSION['rg'] =$RG;
     $_SESSION['cep'] =$CEP;
     $_SESSION['rua'] =$rua;
     $_SESSION['bairro'] =$bairro;
     $_SESSION['estado'] =$estado;

     return true;
    }
    else{
      return false;
    }

    }
    */

}





 ?>