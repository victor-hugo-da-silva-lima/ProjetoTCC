<?php
  require_once 'usuarios.php';
  $u= new Usuario;

?>

<!DOCTYPE html>
<html>
<head>
	<title>Login</title>
	<meta charset="utf-8">
	<link rel="stylesheet" type="text/css" href="estilo.css">
  <link rel="icon" type="image/png" href="../AreaEfetivada/font (2).png">
</head>
<body>
	<div id="corpo">
	<h1>Login</h1>
  <form method="POST">
  	
 <input type="email" placeholder="Usuário" name="email">
 <input type="password" placeholder="Senha" name="senha">
 <input type="submit" value="Acessar">

 <a href="cadastrar.php">   Ainda não faz parte da comunidade?<strong>  Cadastre-se!</strong></a>

  </form>
</div>

<?php
if(isset($_POST['email']))
{
	
	$email=(($_POST['email']));
	$senha=(($_POST['senha']));

	if(!empty($email) && !empty($senha))
	{
	   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");
	
    	if ($u->msgErro=="")
    	 {
    	    
    	    if($u->logar($email,$senha))
          {

           header("location:../AreaEfetivada/HOME1.php");
           
          }
         else
           {
         	        ?>
     		  	   <div class="msgErrada">
                   Email e/ou senha estão errados!
                   </div>
                   <?php 
           }
          
         }
	
}

else
    {
    	       ?>
     		  	   <div class="msgErrada">
                   Preencha todos os campos!
                   </div>
                   <?php 
     }


}

?>
</body>
</html>