<html>
<head>
 
  
    
     
    <script src="https://kit.fontawesome.com/c488a94340.js"></script>
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <style type="text/css">
    label{

  margin-left: 10px;
}
      .card{
                width: 500px;
                margin-left: 190px;

              
    }
    .img-events{

  background-image: url('foto2.jpg');
  background-size: cover;
  background-position: bottom center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: bottom 30px;
  height: 500px;

}
.img-events div{
  text-align: center;
  color: white;
  font-family: sans-serif;
  background-color: rgb(255,140,0,.02);
 
   height: 500px;

}
.img-events::before{
  width: 100%;
  position: absolute;
  background-color: rgb(32,32,32,0.1);

}
#imagem{
  width: 400px;
}
#icone{
  width: 150px;
}
.evento:hover{
  color: #CF070D;
  cursor: pointer;
}
#pow{
  max-width: 100%;
  width: 500px;
  height: 270px;
  object-fit:cover;
}

    
  </style>
	<link rel="stylesheet" type="text/css" href="tcc.CSS">
  <link rel="icon" href="AreaEfetivada/font (2).png">
	<title>POLO</title>
</head>


<body>
  <?php
           include("navBar.php");  
           session_start();
 
 ?>   
<br><br><br>
<div class="img-events">
  <div>
    <br><br><br><br><br><br><br><br>
    <h1>Apolo</h1>
    <h2>O criador de <span style="color:#F28B03; ">Eventos</span></h2>
    <h3>Faça <span style="color: #F28B03;">login</span> e crie o seu!</h3>
    <br><br><br><br><br>
  </div>
</div>
<br><br>
<hr>
<div class="row">
  <div class="col-sm-3"></div>
<div class="col-sm-3">
  <img src="celular.png" id="imagem">
</div>
<div class="col-sm-3" style="margin-bottom: 50px;">
  
  <h2 style="color: #0B698B">Preparamos para a plataforma Mobile também</h2>
  <br>
  <h3>Não perca tempo! Baixe agora</h3>
  <h5 style="color: #0B698B "> Estamos na Play Store</h5>
 <a href="https://play.google.com/store/?utm_source=latam_Med&utm_medium=hasem&utm_content=Feb0217&utm_campaign=Evergreen&pcampaignid=MKT-DR-latam-br-1002290-Med-hasem-py-Evergreen-Feb0217-Text-Institucional&gclid=EAIaIQobChMIu7nsmIac6gIVSQ2RCh3A9QAvEAAYASAAEgK4I_D_BwE&gclsrc=aw.ds" target="_blank"><img src="store.png" id="icone"></a>
</div>
</div>
<hr>
<br><br><br><br><br>
<a name="Evento"></a>
<h2 style="text-align: center;" style="color: #0B698B;">Eventos Próximos!</h2>
<br><br>
<div class="card-deck">
 <?php
 require_once 'login/usuarios.php';

  $u = new Usuario;
   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");

   $pagina_atual=filter_input(INPUT_GET, 'pagina', FILTER_SANITIZE_NUMBER_INT);
   $pagina= (!empty($pagina_atual)) ? $pagina_atual:1;

   $qtd_pagina = 6;
    
    $inicio= ($qtd_pagina* $pagina)- $qtd_pagina;
   //$hoje = date('d/m/Y');
   $sql= $pdo->prepare("SELECT * FROM dadosevento ORDER BY data ASC LIMIT $inicio, $qtd_pagina");
$sql->execute();
while ($lista = $sql->fetch(pdo::FETCH_ASSOC)) {
   ?>

  

  
  
 
   
<div class="col-3">
 <div class="card">
  <?php echo'<img  class="card-img-top" id="pow" src="AreaEfetivada/IMAGEM/'.$lista['id'].'/'.$lista['imagem'].'" /> ';?>
    <div class="card-body">
      <h5 class="card-title"><span class="evento"><?php echo "".$lista['Nome']."<br>";?></span></h5>
      <br>
      <img src="https://img.icons8.com/material-two-tone/16/000000/calendar--v1.png"/><label>Data:</label><?php echo " ".$lista['data']?>
      <p class="card-text"><img src="https://img.icons8.com/small/16/000000/clock.png"/><label>Hora:</label><?php echo " ".$lista['hora'] ?></p>
      <p class="card-text"><img src="https://img.icons8.com/officexs/16/000000/marker.png"/><label>Local</label>:<?php echo " ".$lista['local']; ?></p>

    
      
     
    </div>
</div>

<br><br>

</div>
<div class="col-1"></div>
 
 
<?php } ?>
</div>

           <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
    
    </body>
</html>