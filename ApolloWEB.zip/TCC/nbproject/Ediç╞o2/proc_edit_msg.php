<?php

  require_once'../Login/usuarios.php';
  $u = new Usuario;
  session_start();
   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");

//Verificar se o usuário clicou no botão, clicou no botão acessa o IF e tenta cadastrar, caso contrario acessa o ELSE
$SendEditCont = filter_input(INPUT_POST, 'SendEditCont', FILTER_SANITIZE_STRING);
if($SendEditCont){
    //Receber os dados do formulário dataNasc

    $nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_STRING);
    $RG = filter_input(INPUT_POST, 'RG', FILTER_SANITIZE_STRING);
    $sexo = filter_input(INPUT_POST, 'sexo', FILTER_SANITIZE_STRING);
    $dataNasc = filter_input(INPUT_POST, 'dataNasc', FILTER_SANITIZE_STRING);
    $rua = filter_input(INPUT_POST, 'rua', FILTER_SANITIZE_STRING);
    $bairro = filter_input(INPUT_POST, 'bairro', FILTER_SANITIZE_STRING);
    $estado = filter_input(INPUT_POST, 'estado', FILTER_SANITIZE_STRING);
    $numero = filter_input(INPUT_POST, 'numero', FILTER_SANITIZE_STRING);
    $telefone = filter_input(INPUT_POST, 'telefone', FILTER_SANITIZE_STRING);

    
    //Inserir no BD
    $sql=$pdo->prepare("UPDATE usuarios SET nome=:n, RG=:r, sexo=:sex, dataNasc=:dat, rua=:ru, bairro=:b, estado=:es, numero=:num, telefone=:tel  WHERE id_usuario=".$_SESSION['id_usuario']);
    
    
    $sql->bindParam(':n', $nome);
    $sql->bindParam(':r', $RG);
    $sql->bindParam(':sex', $sexo);
    $sql->bindParam(':dat', $dataNasc);
    $sql->bindParam(':ru', $rua);
    $sql->bindParam(':b', $bairro);
    $sql->bindParam(':es', $estado);
    $sql->bindParam(':num', $numero);
    $sql->bindParam(':tel', $telefone);
    
    if($sql->execute()){
        $_SESSION['msg'] = "<p style='color:green;'>Dados editados com sucesso</p>";
        header("Location: ../AreaEfetivada/Perfil1.php");
    }else{
        $_SESSION['msg'] = "<p style='color:red;'>Mensagem não foi editada com sucesso</p>";
        header("Location: index.php");
    }    
}else{
    $_SESSION['msg'] = "<p style='color:red;'>Mensagem não foi editada com sucesso</p>";
    header("Location: index.php");
}