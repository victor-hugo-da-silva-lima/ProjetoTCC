<!DOCTYPE html>
<html>

<script type="text/javascript">
function formatar_mascara(src, mascara) {
 var campo = src.value.length;
 var saida = mascara.substring(0,1);
 var texto = mascara.substring(campo);
 if(texto.substring(0,1) != saida) {
 src.value += texto.substring(0,1);
 }
}
</script>
<head>
	<?php
       include("navBar1.php");  
           session_start();
  if(!isset($_SESSION['id_usuario']))
  {
    header("location:../Login/index.php");
    exit;
  }
  else{
   require_once '../Login/usuarios.php';
   $u = new Usuario;
 

   if (isset($_SESSION['msg'])) {
   	echo "<br>";
   	echo "<br>";
   	echo $_SESSION['msg'];
   	unset($_SESSION['msg']);
   }
  }
	 ?>
	<title></title>
	<style type="text/css">

		textarea{
    resize: none; /* impede que o próprio usuário altere o tamanho do textarea */
    width:70%;
    height:700px;
    overflow-y: auto;
    margin-left:16%;
    }   
    label{
    	margin-left: 45%;
    }
   .ola{
	
	display: block;
	height: 40px;
	width: 400px;
	margin:15px;
	margin-left: 40%;
	border-radius: 30px;
	border:1px solid black;
	font-size: 13pt;
	padding: 10px 3px;
	
	
	outline: none;

}
.diferente{
	margin-left: 40%;
	margin-bottom: 25px;
}
#corpo{
	border: 1px;
	border-radius: 10px;
	background-color: rgb(220,220,220,0.95);
   margin-left: 25%;
    width: 50%;
    padding: 10px;
}



input{
	margin-bottom: 60px;
}

body{

	  background-image: url('Body.jpg');
  background-size: cover;
  background-position: bottom center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: bottom 30px;
  height: 400px;

}

.backgroundModificado {
       background-color: #abcdef;
   }


	</style>



</head>
<body>
<br><br>
<div class="img-events">

<div id="corpo">
<form method="POST" enctype="multipart/form-data">
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputEmail4"><h5>Nome</h5></label>
      <input type="text" class="form-control" id="inputEmail4" placeholder="Nome do evento"  name="nome">
    </div>
    <div class="form-group col-md-6">
      <label for="inputPassword4"><h5>Local</h5></label>
      <input type="text" class="form-control" id="inputPassword4" placeholder="local do evento"  name="local">
    </div>
  </div>
  <div class="form-row">
  <div class="form-group col-md-6">
    <label for="inputAddress"><h5>Data</h5></label>
    <input type="text" class="form-control" id="inputAddress" placeholder="digite a data do Evento"  name="data" onkeypress="formatar_mascara(this,'##/##/####')">
  </div>
  <div class="form-group col-md-6">
    <label for="inputAddress2"><h5>Hora</h5></label>
    <input type="time" class="form-control" id="inputAddress2" placeholder="Apartment, studio, or floor"  name="hora">
  </div>
</div>
  <div class="form-row">
    <div class="form-group col-md-6">
      <label for="inputCity"><h5>Imagem de capa </h5></label>
      <input type="file" class="form-control" id="inputCity"  name="imagem" >
    </div>
    <div class="form-group col-md-6">
      <label for="inputState"><h5>Preço</h5></label>
    <input type="text" class="form-control" id="inputAddress2" name="preco">
    </div>
    <div class="form-group col-md-12">
        <label for="inputState"><h5><span>Descrição</span></h5></label>
        <textarea name="descricao"></textarea>
    </div>
<br>

  <input type="submit" id="Submit69" class="btn btn-default btn-block backgroundModificado" style="background-color: #aaaaaa"
        value="Cadastrar" title="Verifique se as informações estão corretas" name="SendCadImg" /> 
</form>
</div>
</form>
</div>
<?php 
  $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");
$SendCadImg = filter_input(INPUT_POST,'SendCadImg', FILTER_SANITIZE_STRING);

  if($SendCadImg){

  	$nome = filter_input(INPUT_POST,'nome', FILTER_SANITIZE_STRING);
  	$nome_imagem= $_FILES['imagem']['name'];
    $preco = filter_input(INPUT_POST,'preco', FILTER_SANITIZE_STRING);
    $data = filter_input(INPUT_POST,'data', FILTER_SANITIZE_STRING);
    $hora = filter_input(INPUT_POST,'hora', FILTER_SANITIZE_STRING);
    $local = filter_input(INPUT_POST,'local', FILTER_SANITIZE_STRING);
    $descricao = filter_input(INPUT_POST,'descricao', FILTER_SANITIZE_STRING);

  	$sql= $pdo->prepare("INSERT INTO dadosevento (Nome,imagem,preco,data,hora,local,descricao) VALUES (:n, :img, :p, :d, :h, :l, :des)");
  	 $sql->bindParam(':n', $nome);
  	 $sql->bindParam(':img',$nome_imagem);
  	 $sql->bindParam(':p', $preco);
  	 $sql->bindParam(':d', $data);
  	 $sql->bindParam(':h', $hora);
  	 $sql->bindParam(':l', $local);
  	 $sql->bindParam(':des', $descricao);

        
  	if($sql->execute()){
        
       $ultimo_id = $pdo->lastInsertId();

      $diretorio ='IMAGEM/'.$ultimo_id.'/';

      mkdir($diretorio, 0755);
      move_uploaded_file($_FILES['imagem'] ['tmp_name'], $diretorio.$nome_imagem);


      


  	}
  	
  }
  else{
      $_SESSION['msg']="<p style='color:red;'> Erro ao salvar os dados</p>";
  }

   

?>
</script>


           <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>