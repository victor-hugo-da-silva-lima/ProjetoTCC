<html>
<head>
    <?php
           include("navBar1.php");  
           session_start();
  if(!isset($_SESSION['id_usuario']))
  {
    header("location:../Login/index.php");
    exit;
  }
?>
           
    <script src="https://kit.fontawesome.com/c488a94340.js"></script>
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <style type="text/css">
    .card{
                width: 500px;
             

              
    }  
 .carousel-item{
 
   background-size: cover;
  background-position: bottom center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: bottom 30px;
  height: 550px;
  border-radius: 100px;

 }
 .carrousel-item::before{
  width: 100%;
  position: absolute;
  background-color: rgb(250,128,114,.5);

}
.carrousel-caption{
  background-color: rgb(250,128,114,.5);
}
h1{

  text-align: center;
  margin-bottom: 190px;
  color:white;
  
}
#ola{
  
   background-size: cover;
  background-position: bottom center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: bottom 30px;
  height: 400px;
  border-radius: 30px;
  
  background-color: rgb(32,32,32,0.01);

  

}
#imagem{

   width: 400px;
}
 .img-events{

  background-image: url('../foto2.jpg');
  background-size: cover;
  background-position: bottom center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: bottom 30px;
  height: 430px;

}
.img-events div{
  text-align: center;
  color: white;
  font-family: sans-serif;
  background-color: rgb(255,140,0,.04);
   height: 550px;
 

}
#botao{

  margin-left: 45%;

}
#bot{
  width: 150px;
  height: 65px;
}
footer{
  color:white;

}
#espaço{
  width: 100%;
   background-color: rgb(255,140,0,.05);
  height: 75px;
}
.evento:hover{
  color: #CF070D;
  cursor: pointer;
  
}
.evento{
  margin-left: 20px;
}
#pow{
  max-width: 100%;
  width: 500px;
  height: 270px;
  object-fit:cover;
}
label{

  margin-left: 10px;
}
#panda{
    width: 100%;
  position: absolute;
  background-color: rgb(250,128,114,.5);
}
  </style>
	<link rel="stylesheet" type="text/css" href="tcc1.CSS">
	<title>IParty</title>
</head>


<body>
  <br><br><br>
<div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
  <ol class="carousel-indicators">
    <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
    <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
   
  </ol>
  <div class="carousel-inner">
  
    <div class="carousel-item active">
      <img class="d-block w-100" src="oi2.jpg" alt="first slide">
       <div class="carousel-caption d-none d-md-block" id="ola">
    <h1>EM BREVE! MELHOR FESTA ANO!</h1>
  </div>
    </div>
    <div class="carousel-item">
      <img class="d-block w-100" src="oi.jpg" alt="second slide">
       <div class="carousel-caption d-none d-md-block" id="ola">
    <h1>EM BREVE! MELHOR FESTA ANO!</h1>
  </div>
    </div>
  </div>
  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
    <span class="sr-only">Previous</span>
  </a>
  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
    <span class="carousel-control-next-icon" aria-hidden="true"></span>
    <span class="sr-only">Next</span>
  </a>
</div>


<div id="espaço">
  
</div>
<div class="img-events">
  <div>
    <br><br><br><br><br><br><br><br>
    <h2>Agora <span style="color: #F28B03;">Crie</span> ou Compre Eventos!</h2>
    <h3>Procure <span style="color: #F28B03;">Armazens</span> e <span style="color: #F28B03;">Chácaras</span> nas opções do menu!</h3>
    <h4><span style="color: #F28B03;">Simule </span>suas compras em <span style="color: #F28B03;">Dicas!</span></h4>
    <br><br><br><br><br>
  </div>
</div>

<br><br><br><br><br>
<form>
  <br>
<h2 style="text-align: center;">Eventos Próximos!</h2>
<br><br>
<div class="row">
<div class="card-deck">
 <?php
 require_once '../login/usuarios.php';

  $u = new Usuario;
   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");

   $pagina_atual=filter_input(INPUT_GET, 'pagina', FILTER_SANITIZE_NUMBER_INT);
   $pagina= (!empty($pagina_atual)) ? $pagina_atual:1;

   $qtd_pagina = 6;
    
    $inicio= ($qtd_pagina* $pagina)- $qtd_pagina;
   //$hoje = date('d/m/Y');
   $sql= $pdo->prepare("SELECT * FROM dadosevento ORDER BY data ASC LIMIT $inicio, $qtd_pagina");
$sql->execute();
while ($lista = $sql->fetch(pdo::FETCH_ASSOC)) {
   ?>

  

  
  
 
   
<div class="col-3">
 <div class="card">
  <?php echo'<img  class="card-img-top" id="pow" src="IMAGEM/'.$lista['id'].'/'.$lista['imagem'].'" /> ';?>
    <div class="card-body">
      <h5 class="card-title"><span class="evento"><?php echo "".$lista['Nome']."<br>";?></span></h5>
      <br>
      <img src="https://img.icons8.com/material-two-tone/16/000000/calendar--v1.png"/><label>Data:</label><?php echo " ".$lista['data']?>
      <p class="card-text"><img src="https://img.icons8.com/small/16/000000/clock.png"/><label>Hora:</label><?php echo " ".$lista['hora'] ?></p>
      <p class="card-text"><img src="https://img.icons8.com/officexs/16/000000/marker.png"/><label>Local</label>:<?php echo " ".$lista['local']; ?></p>

    
      
     
    </div>
</div>

<br><br>

</div>
<div class="col-1"></div>
 
 
<?php } ?>
</div>

<div id="botao">
<a href="eventos.php" class="btn btn-outline-info btn-lg" role="button" aria-pressed="true" id="bot">More</a>
</div>


<script>
  $('.carousel').carousel({
  interval: 1500
})
</script>


           <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
    
    </body>
</html>