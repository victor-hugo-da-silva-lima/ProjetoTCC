<html>
<head>
    <?php
           include("navBar1.php");  
           session_start();
           if(!isset($_SESSION['id_usuario']))
  {
    header("location:../Login/index.php");
    exit;
  }
  else{
      require_once '../login/usuarios.php';

  $u = new Usuario;
   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");
  }

        ?>
           
    <script src="https://kit.fontawesome.com/c488a94340.js"></script>
  <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <style>
    #rodape{
      border-top:0.2px solid lightgray;
       background-color: white;
      height: 270px;
       width: 100%;
  
    }
 #info
 {
  color:  #363636;
 }
 p:hover{
  cursor: pointer;
  
 }
 .antes{
  width: 100%;
  height: 30px;
  background-color: rgb(255,140,0,.08);
 }
 .card{
                width: 500px;
                margin-left: 190px;

              
    }
    .img-events{

  background-image: url('../foto2.jpg');
  background-size: cover;
  background-position: bottom center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: bottom 30px;
  height: 400px;

}
h2{

  text-align: center;
 
  color:white;
  
}
h3{
  text-align: center;
  color:white;
}
h4{
  text-align: center;
  color:white;
}
#pow{

  max-width: 100%;
  width: 500px;
  height: 270px;
  object-fit:cover;
}
.po{
  margin-right: 200px;
}
label{
  margin-left: 10px;
  font-weight: bold;
}
.pag{

  border: 1px;
  border-radius: 10px;
  background-color: rgb(220,220,220,0.95);
   margin-left: 35%;
    width: 30%;
    padding: 10px;
}
.ufa{

  text-align: center;
  margin-left: 6%;
  margin-right: 6%;
}



  </style>
  <link rel="stylesheet" type="text/css" href="tcc1.CSS">
  <title>IParty</title>
</head>


<body style="background-color: rgb(255,140,0,.05);">
    
<br><br>
<br><br><br><br>
<div class="card-deck">

  <?php 


    $sql= $pdo->prepare("SELECT * FROM armazem ORDER BY idarmazem ASC ");
$sql->execute();
while ($lista = $sql->fetch(pdo::FETCH_ASSOC)) {
   
 //echo "".$lista['imagem'];."<br>";
 //echo "".$lista['Nome']."<br>";
// echo "".$lista['preco']."<br>";
 //echo "".$lista['data']."<br>";
 //echo "".$lista['hora']."<br>";
 //echo "".$lista['local']."<br>";
 //echo "".$lista['descricao']."<br>";
//echo "<br>";


//class="card-img-top" alt="Card image cap"
?>
<div class="col-1"></div>
<div class="col-4">
 <div class="card">
 <img src="armazem2.jpeg" id="pow">
    <div class="card-body">
      <h5 class="card-title"><span class="evento"><?php echo "".$lista['nomeArmazem']."<br>";?></span></h5>
      <br>
      <img src="o-email.png"/><label>Email:</label><?php echo " ".$lista['cidadeArmazem']?>
      <p class="card-text"><img src="tel.png"/><label>Telefone:</label><?php echo "  ".$lista['telefone'] ?></p>
      <p class="card-text"><img src="https://img.icons8.com/officexs/16/000000/marker.png"/><label>Rua</label>:<?php echo "  ".$lista['ruaArmazem']; ?></p>
       <p class="card-text"><img src="https://img.icons8.com/officexs/16/000000/marker.png"/><label>Numero</label>:<?php echo "  ".$lista['numeroArmazem']; ?></p>
        <p class="card-text"><img src="https://img.icons8.com/officexs/16/000000/marker.png"/><label>Bairro</label>:<?php echo "  ".$lista['bairroArmazem']; ?></p>


      <p class="card-text"><?php //echo nl2br("".$lista['descricao']."<br>");?></p>
      <p class="card-text"> 
      
     
      <div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Descrição
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <p><?php echo nl2br("".$lista['des']."<br>"); ?></p>
      </div>
    </div>
  </div>
</div>  

      </p>
    </div>
</div>
<br>

<br>

</div>
<div class="col-1"></div>
 
 
<?php } ?>


</div>
<div id="rodape">
  <br><br><br>
   <div class="row">
    <div class="col-md-1"></div>
     <div class="col-md-2"><img src="logo_sizeP.jpg"  width="180px" class="rounded-circle"></div>
     <div class="col-md-2" id="info">
      <h5>Festa</h5>
      <p>Criar a minha</p>
      <p>Tudo certo</p>
      <p>Esta bem</p>
     </div>

     <div class="col-md-2" id="info">
      <h5>Perfil</h5>
      <p>Editar</p>
      <p>Configurar</p>
      <p>Restaurar</p>
     </div>
     <div class="col-md-2" id="info">
      <h5>Ajuda</h5>
      <p>Fale conosco</p>
      <p>Quero Premiun</p>
      <p>Classificar</p>
     </div>
     <div class="col-md-2" id="info">
      <h5>Social</h5>
      <p>Instagran</p>
      <p>Facebook</p>
      <p>Twitter</p>
     </div>
       </div>

</div>

          <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
</body>
</html>