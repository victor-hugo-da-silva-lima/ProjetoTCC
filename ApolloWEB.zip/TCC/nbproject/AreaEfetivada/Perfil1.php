
<?php 

  require_once '../Login/usuarios.php';
  $u = new Usuario;
   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");
 ?>
<!DOCTYPE html>
<html>
<script type="text/javascript">
function formatar_mascara(src, mascara) {
 var campo = src.value.length;
 var saida = mascara.substring(0,1);
 var texto = mascara.substring(campo);
 if(texto.substring(0,1) != saida) {
 src.value += texto.substring(0,1);
 }
}
</script>
<head>
    <script src="https://kit.fontawesome.com/c488a94340.js"></script>
  <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  <link rel="stylesheet" type="text/css" href="tcc.CSS">
  <title>POLO</title>

</head>
<style>
	.perfil{
	
		margin-left: 43%;
    position: center;
	}
  .perfil1{
    margin-top: 300px;
    margin-left: 43%;
  }
  .msgSucesso{
     width: 400px;
    margin:10px auto;
    color: white;
    padding: 10px;
    background-color: rgb(50,205,50,.3);
    border:1px solid rgb(34,139,34);
    text-align: center;
  }
</style>
<?php

         
           session_start();
           if(!isset($_SESSION['id_usuario']))
  {
    header("location:../Login/index.php");
    exit;
  }
  else{
 
     include('navBar1.php');
   $sql=$pdo->prepare("SELECT * FROM usuarios WHERE id_usuario=".$_SESSION['id_usuario']);
    $sql->execute();
    $lista=$sql->fetch(pdo::FETCH_ASSOC);

     /*echo "<div class='perfil1'><h1>" . $lista['nome'] . "</h1> <h4> seja bem-vindo(a) ao nosso site!</h4></div>";
      echo "<div class='perfil'>E-mail: " . $lista['email'] . "<br></div>";
      echo "<div class='perfil'>CPF: " . $lista['RG'] . "<br></div>";
      echo "<div class='perfil'>CEP: " . $lista['CEP'] . "<br></div>";
      echo "<div class='perfil'>Rua: " . $lista['rua'] . "<br></div>";
      echo "<div class='perfil'>Bairro: " . $lista['bairro'] . "<br></div>";
       echo "<div class='perfil'>Estado:  " . $lista['estado'] . "<br></div>"; */
  }
        ?>
  
  <br><br><br><br><br>
<body style="background-color: rgb(255,140,0,.045);">
<div class="container" id="jum">
  <div class="jumbotron" style="background-color: lightgray;" opacity="100%" >
  <h1 class="display-4"><?php  echo"". $lista['nome'];?></h1>
  <p class="lead">Seja bem vindo(a) ao nosso site</p>
  <hr class="my-4">
 <p> Abra seus Dados</p>
 
<!-- Inico form-->
<div class="accordion" id="accordionExample" >
  <div class="card">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Dados
        </button>
      </h2>
    </div>

    <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
        <form class="needs-validation" novalidate method="Post" action="../Edição2/proc_edit_msg.php">
  <div class="form-row">
  
 
  <div class="form-row">
     <div class="col-md-3 mb-3">
      <label for="validationCustom03">Nome</label>
      <input maxlength="50" type="text" class="form-control" id="validationCustom03" name="nome"  value="<?php  echo "" . $lista['nome'] . ""; ?>">
    </div>
    <div class="col-md-3 mb-3">
      <label for="validationCustom03">CPF</label>
      <input maxlength="11" type="text" class="form-control" id="validationCustom03" name="RG"  value="<?php  echo "" . $lista['rg'] . ""; ?>">
    </div>
    <div class="col-md-3 mb-3">
      <label for="validationCustom04">Sexo</label>
      <input maxlength="1" type="text" class="form-control" id="validationCustom04" name="sexo"  value="<?php echo "" . $lista['sexo'] . ""; ?>">
    </div>

     <div class="col-md-3 mb-3">
      <label for="validationCustom04">Data de Nascimento</label>
      <input maxlength="10" type="text" class="form-control" id="validationCustom04" name="dataNasc"  onkeypress="formatar_mascara(this,'##/##/####')"  value="<?php echo "" . $lista['dataNasc'] . ""; ?>">
    </div>

    <div class="col-md-3 mb-3">
      <label for="validationCustom05">Rua</label>
      <input maxlength="55" type="text" class="form-control" id="validationCustom05" name="rua"  value="<?php   echo "" . $lista['rua'] . ""; ?>" >
    </div>
     <div class="col-md-3 mb-3">
      <label for="validationCustom04">Bairro</label>
      <input maxlength="30" type="text" class="form-control" id="validationCustom04" name="bairro" value="<?php   echo "" . $lista['bairro'] . ""; ?>">
    </div>
     <div class="col-md-3 mb-3">
      <label for="validationCustom04">Estado</label>
      <input maxlength="3" type="text" class="form-control" id="validationCustom04" name="estado"  value="<?php   echo "" . $lista['estado'] .""; ?>">
    </div>

     <div class="col-md-1 mb-3">
      <label for="validationCustom04">Numero</label>
      <input maxlength="45" type="text" class="form-control" id="validationCustom04" name="numero"  value="<?php   echo "" . $lista['numero'] .""; ?>">
    </div>
    <div class="col-md-2 mb-3">
      <label for="validationCustom04">Telefone</label>
      <input maxlength="45" type="text" class="form-control" id="validationCustom04" name="telefone"  value="<?php   echo "" . $lista['telefone'] .""; ?>">
    </div>
  </div>
  <input name="SendEditCont" type="submit" value="Editar dados" class="btn btn-primary">
 
</form>
      </div>
    </div>
  </div>
</div>  



<!-- Modal -->
<div class="modal fade" id="exampleModalScrollable" tabindex="-1" role="dialog" aria-labelledby="exampleModalScrollableTitle" aria-hidden="true">
  <div class="modal-dialog modal-dialog-scrollable" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalScrollableTitle">Modal title</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        1. ACEITAÇÃO
Este é um contrato firmado entre você, de agora em diante denominado como usuário, e a Webnow Tecnologia
e Marketing Digital Ltda, empresa cadastrada no CNPJ sob nº 05.232.644/0001-29 com sede no município de São
Paulo, capital do estado, a Av. das Nações Unidas 12.995 – 10º andar, e de agora em diante denominada
simplesmente de Webnow. Este “Termo de Uso de Aplicativo” rege o uso de todos os aplicativos
disponibilizados gratuitamente pela Webnow sejam para dispositivos móveis (Android, IOS, Windows Mobile),
servidores, computadores pessoais (desktops) ou serviços web. Se você não concordar com estes termos não
use este aplicativo.
Você reconhece que analisou e aceitou as condições de uso. Leia-as atentamente pois o uso deste aplicativo
significa que você aceitou todos os termos e concorda em cumpri-los. Se você, usuário, for menor de idade ou
declarado incapaz em quaisquer aspectos, precisará da permissão de seus pais ou responsáveis que também
deverão concordar com estes mesmos termos e condições.
2. LICENÇA LIMITADA
Você recebeu uma licença limitada, não transferível, não exclusiva, livre de royalties e revogável para baixar,
instalar, executar e utilizar este aplicativo em seu dispositivo. Você reconhece e concorda que a Webnow
concede ao usuário uma licença exclusiva para uso e desta forma não lhe transfere os direitos sobre o produto.
O aplicativo deverá ser utilizado por você, usuário. A venda, transferência, modificação, engenharia reversa ou
distribuição bem como a cópia de textos, imagens ou quaisquer partes nele contido é expressamente proibida.
3. ALTERAÇÕES, MODIFICAÇÕES E RESCISÃO
A Webnow reserva-se no direito de, a qualquer tempo, modificar estes termos seja incluindo, removendo ou
alterando quaisquer de suas cláusulas. Tais modificações terão efeito imediato. Após publicadas tais alterações,
ao continuar com o uso do aplicativo você terá aceitado e concordado em cumprir os termos modificados.
A Webnow pode, de tempos em tempos, modificar ou descontinuar (temporária ou permanentemente) a
distribuição ou a atualização deste aplicativo.
A Webnow não é obrigada a fornecer nenhum serviço de suporte para este aplicativo.
O usuário não poderá responsabilizar a Webnow nem seus diretores, executivos, funcionários, afiliados, agentes,
contratados ou licenciadores por quaisquer modificações, suspensões ou descontinuidade do aplicativo.

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-danger" >Recusar</button>
        <button type="button" class="btn btn-outline-success" data-dismiss="modal">Aceitar</button>
      </div>
    </div>
  </div>
</div>
  <br>
  
  
  <button id="b1" type="button" class="btn btn-primary " data-toggle="modal" data-target="#exampleModalScrollable">
  Termos de uso
</button>

</div>
</div>
<br><br>
<?php 

//if(isset($_SESSION['msg'])){
  //      <div class="msgSucesso"><?php echo $_SESSION['msg'];?>
          <?php
    //        unset($_SESSION['msg']);
        //}
?>

  
 

<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>



<script>
// Example starter JavaScript for disabling form submissions if there are invalid fields
(function() {
  'use strict';
  window.addEventListener('load', function() {
    // Fetch all the forms we want to apply custom Bootstrap validation styles to
    var forms = document.getElementsByClassName('needs-validation');
    // Loop over them and prevent submission
    var validation = Array.prototype.filter.call(forms, function(form) {
      form.addEventListener('submit', function(event) {
        if (form.checkValidity() === false) {
          event.preventDefault();
          event.stopPropagation();
        }
        form.classList.add('was-validated');
      }, false);
    });
  }, false);
})();


</script>


</body>
</html>