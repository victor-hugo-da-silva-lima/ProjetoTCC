<html>
    <head>
        <title>POLO</title>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
         <script src="https://kit.fontawesome.com/c488a94340.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">

	<link rel="stylesheet" type="text/css" href="tcc1.CSS">

	<title>Apolo</title>
  <link rel="icon" type="image/png" href="font (2).png">
    </head>
    <body>
 
        <nav id="sombra" class="navbar fixed-top navbar-expand-lg navbar-light shadow bg-white ">
  <a class="navbar-brand" href="HOME1.php" style="margin-top: 5px;">
  	<img src="logo_sizeP.jpg" style="" sizes="30px" width="50px" class="rounded-circle"> Apolo</a>
  
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#menuSanduba" >
    <span class="navbar-toggler-icon"></span>
  </button>

  <div class="collapse navbar-collapse" id="menuSanduba">
    <ul class="navbar-nav mr-auto">
     <li class="nav-item active"></li>
      <li class="nav-item active">
        <a class="nav-link" href="HOME1.php" id="home" ><i class="fas fa-home" style="color: lightgray;"></i> Home<span class="sr-only">(current)</span></a>
      </li>
     
      <li class="nav-item">
        <a class="nav-link" href="armazens1.php" style="margin-top: 9px;">Armazens</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="chacaras1.php"style="margin-top: 9px;">Chacaras</a>
      </li>
      <li class="nav-item dropdown">
        <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false" style="margin-top: 9px;">
    Dicas        </a>
        <div class="dropdown-menu" aria-labelledby="navbarDropdown">
          <a class="dropdown-item" href="#">Bebidas</a>
          <a class="dropdown-item" href="Simulador.php">Simulador</a>
          <div class="dropdown-divider">adas</div>
          <a class="dropdown-item" href="#"><span class="fas fa-cog" style="color: gray;"></span>Configurações</a>
        </div>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="Perfil1.php"style="margin-top: 9px;">Perfil</a>
      </li>
       <li class="nav-item">
       <a class="nav-link" href="eventos.php" style="margin-top: 9px;">Eventos</a>
     </li>
      <li class="nav-item">
       <a class="nav-link" href="../Login/Sair.php" style="margin-top: 9px;">Sair</a>
     </li>
      <li class="nav-item">
        <a class="nav-link " href="Evento.php" tabindex="-1" ><button class="btn btn-info my-2 my-sm-0" type="button" >
  
  Criar Evento!
</button></a>
      </li>
      
    </ul>
     
    <form class="form-inline my-2 my-lg-0">
      <div class="input-group">
        <div class="input-group-prepend">
          <span class="input-group-text">
            <i class="fas fa-search"></i>     
          </span>
        </div>
      
      <input class="form-control mr-sm-3" type="search" placeholder="Busca" aria-label="Search">
    </div>
    <button type="button" class="btn btn-outline-info">Busca</button>
    </form>

   
</nav>
        
        
        
    </body>
</html>