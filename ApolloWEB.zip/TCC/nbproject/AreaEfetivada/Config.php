<!DOCTYPE html>
<html>
<head>
	<title></title>
</head>
<body>
<?php
 

 require_once '../login/usuarios.php';

  $u = new Usuario;
   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");
 
 $sql=$pdo->prepare("SELECT id FROM dadosevento");
    	$sql->execute();

while ($lista = $sql->fetch(pdo::FETCH_ASSOC)) {

		echo "".$lista['id'];
	
	 // echo "".$_SESSION['id'];
	
  
}
 
  
      

   

?>




</body>
</html>