<!DOCTYPE html>
<html>
<head>
		 <script src="https://kit.fontawesome.com/c488a94340.js"></script>
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<?php
	//     session_start();
  //if(!isset($_SESSION['id_usuario']))
 // {
   //header("location:../Login/index.php");
  //  exit;
  //}
  //else{
	
 //include("navBar1.php");  
      //     session_start();
 // if(!isset($_SESSION['id_usuario']))
 // {
  //  header("location:../Login/index.php");
 //   exit;
  //}
  //else{
  	//session_start();
	// require_once '../login/usuarios.php';
	 require_once'Config.php';
 // $u = new Usuario;
 //  $u->conectar("evento","localhost","root","");
 // $sql= $pdo->prepare("SELECT * FROM dadosevento Where id=".$_SESSION['id']);
 // $sql->execute();
  //while ($lista = $sql->fetch(pdo::FETCH_ASSOC)) {
 // echo "".$lista['id'];
//}


	?>
	<title></title>
</head>
<body>

</body>
</html>