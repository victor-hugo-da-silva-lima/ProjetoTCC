<!DOCTYPE html>
<html>
<head>
	<?php
           include("navBar1.php");  
           session_start();
           if(!isset($_SESSION['id_usuario']))
  {
    header("location:../Login/index.php");
    exit;
  }
        ?>
        <style type="text/css">
          label{
           
            margin-left: 25%;
          }
          #wow{
          border: 1px;
  border-radius: 10px;
  background-color: rgb(220,220,220,0.95);
   margin-left: 25%;
    width: 50%;
    padding: 10px;
       
          }
          .al{
             margin-left: 25%;
    width: 50%;
          }
          div#msgSucesso{
    
    width: 400px;
    margin:10px auto;
    color: black;
    padding: 10px;
    background-color: rgb(50,205,50,.3);
    border:1px solid rgb(34,139,34);
    text-align: center;
}

div.msgErrada{
    width: 400px;
    margin:10px auto;
    color: black;
    padding: 10px;
    background-color: rgb(250,128,114,.3);
    border:1px solid rgb(165,42,42);
    text-align: center;

}

        </style>
	<title></title>
</head>
<body>
	<br><br><br><br><br><br>
<?php 
if(!isset( $_SESSION['conta'])) {
?>
<div id="wow"> 
  <h5 style="text-align: center;"> Seja bem vindo ao Simulador!</h5>
  <hr>

         <div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Local
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
        <form method="POST">  
  <label>Preço gasto com o Local do evento</label>
  <input type="text" name="resp2" placeholder="" class="al">
 
<br><br>


<form method="POST">
 <input type="submit" name="bot1" value="Próximo" class="al">
</form>
  </div>
    </div>
  </div>
</div>
 <?php


?>

<?php
     $bot1 = filter_input(INPUT_POST,'bot1', FILTER_SANITIZE_STRING);
    if($bot1){
       $resp2 = filter_input(INPUT_POST,'resp2', FILTER_SANITIZE_STRING);
      
        $_SESSION['resp2']=$resp2;
     ?>
        <div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Ingressos
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
     <form method="POST">
      <label>Qual o preço ganho com os ingressos?</label>
      <input type="text" name="resp3" class="al">
    <br><br>
       
           
<form method="POST">
 <input type="submit" name="bot2" value="Próximo" class="al">

 <?php
  }
 ?>

<?php
 $bot2 = filter_input(INPUT_POST,'bot2', FILTER_SANITIZE_STRING);
if($bot2)
{
   $resp3 = filter_input(INPUT_POST,'resp3', FILTER_SANITIZE_STRING);
  
        $_SESSION['resp3']=$resp3;




 ?>
<div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Atração
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
     <form method="POST">
      <label >Qual o preço gasto com a atração ou DJ do evento?</label>
      <input type="text" name="resp4" class="al">
      <br><br>
       
           
<form method="POST">
 <input type="submit" name="bot3" value="Próximo" class="al">
<?php } ?>
<?php

 $bot3 = filter_input(INPUT_POST,'bot3', FILTER_SANITIZE_STRING);
if($bot3)
{
   $resp4 = filter_input(INPUT_POST,'resp4', FILTER_SANITIZE_STRING);
    
        $_SESSION['resp4']=$resp4;
?>
<div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Segurança
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
     <form method="POST">
      <label >Qual o preço gasto com a Segurança do evento?</label>
      <input type="text" name="resp5" class="al">
     <br><br>
       
           
<form method="POST">
 <input type="submit" name="bot4" value="Próximo" class="al">
 <?php } ?>
  
  <?php 

$bot4 = filter_input(INPUT_POST,'bot4', FILTER_SANITIZE_STRING);
if($bot4)
{
   $resp5 = filter_input(INPUT_POST,'resp5', FILTER_SANITIZE_STRING);
    
        $_SESSION['resp5']=$resp5;

?>

<div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Extra
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
     <form method="POST">
      <label><p>Qual o preço gasto extra do evento Seu Evento?</p>
      <p> Se não tiver apenas clique em próximo</p></label>
      <input type="text" name="resp6" class="al">
    <br><br>
       
           
<form method="POST">
 <input type="submit" name="bot5" value="Próximo" class="al">
 <?php } ?>

<?php 

 $bot5 = filter_input(INPUT_POST,'bot5', FILTER_SANITIZE_STRING);
if($bot5)
{
   $resp6 = filter_input(INPUT_POST,'resp6', FILTER_SANITIZE_STRING);
    
        $_SESSION['resp6']=$resp6;
     
?>
<div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
        
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Extra
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
     <form method="POST">
      <label>Qual o preço gasto com as bebidas do seu evento?</label>
      <input type="text" name="resp7" class="al">
    <br><br>

      <form method="POST">
     <input type="submit" name="bot6" value="Próximo" class="al">
     
 <?php } ?>
 <?php 

 $bot6 = filter_input(INPUT_POST,'bot6', FILTER_SANITIZE_STRING);
if($bot6)
{
   $resp7 = filter_input(INPUT_POST,'resp7', FILTER_SANITIZE_STRING);
    
        $_SESSION['resp7']=$resp7;
    
 ?>
<br>
<hr>
<br>
<form method="POST">
<input type="submit" name="calc" value="Calcular" class="al">
<?php } ?>
</form><?php

?>
</div>

 <?php 

           
           $calc = filter_input(INPUT_POST,'calc', FILTER_SANITIZE_STRING);
if($calc)
{
           
           $conta =  ($_SESSION['resp3']) - ( $_SESSION['resp2'] + $_SESSION['resp4'] +  $_SESSION['resp5'] + $_SESSION['resp5'] + $_SESSION['resp6'] +  $_SESSION['resp7']);

           if($conta>0){
              ?>
               <div id="msgSucesso">
                   Seu lucro foi de <?php echo"$ ".$conta;?>
                   </div>
                   <?php 

           }
           else if($conta<0){
            ?>
               <div class="msgErrada">
                   Seu Prejuíjo foi de <?php echo "$ ".-1*($conta);?>
                   </div>
                   <?php 
           }
           else{
           ?>
               <div id="msgSucesso">
                  Não teve gastos nem ganhos!
                   </div>
                   <?php 
           }


           $_SESSION['conta']= $conta;
           unset($_SESSION['conta']);
         }
          
         }
         else{
          echo "ola";
        }

 ?>



 </script>


           <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
 </body>
</html>