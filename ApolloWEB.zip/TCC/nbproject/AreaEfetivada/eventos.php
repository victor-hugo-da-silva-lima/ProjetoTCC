<!DOCTYPE html>
<html>
<head>
	 <script src="https://kit.fontawesome.com/c488a94340.js"></script>
	<meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
	<?php 
	   include("navBar1.php");  
           session_start();
  if(!isset($_SESSION['id_usuario']))
  {
    header("location:../Login/index.php");
    exit;
  }
  else{
	 require_once '../login/usuarios.php';

  $u = new Usuario;
   $u->conectar("cl18151","143.106.241.3","cl18151","cl*25072002");
}

	?>
	<style type="text/css">
		.card{
                width: 500px;
                margin-left: 190px;

              
		}
    .card:hover{
      transition-delay: 0.15s;
      cursor: pointer;
      box-shadow: 0 0 1em rgba(50, 50, 50, 0.25);
    }
		.img-events{

  background-image: url('../foto2.jpg');
  background-size: cover;
  background-position: bottom center;
  background-repeat: no-repeat;
  background-attachment: fixed;
  background-position: bottom 30px;
  height: 400px;

}
h2{

  text-align: center;
 
  color:white;
  
}
h3{
  text-align: center;
  color:white;
}
h4{
	text-align: center;
  color:white;
}
#pow{

	max-width: 100%;
	width: 500px;
	height: 270px;
	object-fit:cover;
}
.po{
	margin-right: 200px;
}
label{
	margin-left: 10px;
   font-weight: bold;
}
.pag{

	border: 1px;
	border-radius: 10px;
	background-color: rgb(220,220,220,0.95);
   margin-left: 35%;
    width: 30%;
    padding: 10px;
}
.ufa{

	text-align: center;
	margin-left: 6%;
	margin-right: 6%;
}
p:hover{
  cursor: pointer;
 
 }
	</style>
	<title></title>
</head>
<body>
	<div class="img-events">
  <div>
    <br><br><br><br><br><br><br><br>
    <h2>Agora <span style="color: #F28B03;">Procure</span> e Compre Eventos!</h2>
    <h3>Crie <span style="color: #F28B03;">SEU </span>Evento na opção do menu <span style="color: #F28B03;">Criar Evento!</span></h3>
   
    <br><br><br><br><br>
  </div>
</div>
<br><br>
	<div class="card-deck">
	
<?php

function Mask($mask,$str){

    $str = str_replace(" ","",$str);

    for($i=0;$i<strlen($str);$i++){
        $mask[strpos($mask,"#")] = $str[$i];
    }

    return $mask;

}

   $pagina_atual=filter_input(INPUT_GET, 'pagina', FILTER_SANITIZE_NUMBER_INT);
   $pagina= (!empty($pagina_atual)) ? $pagina_atual:1;

   $qtd_pagina = 6;
    
    $inicio= ($qtd_pagina* $pagina)- $qtd_pagina;
   //$hoje = date('d/m/Y');
   $sql= $pdo->prepare("SELECT * FROM dadosevento ORDER BY id ASC LIMIT $inicio, $qtd_pagina");
$sql->execute();
while ($lista = $sql->fetch(pdo::FETCH_ASSOC)) {
   
 //echo "".$lista['imagem'];."<br>";
 //echo "".$lista['Nome']."<br>";
// echo "".$lista['preco']."<br>";
 //echo "".$lista['data']."<br>";
 //echo "".$lista['hora']."<br>";
 //echo "".$lista['local']."<br>";
 //echo "".$lista['descricao']."<br>";
//echo "<br>";


//class="card-img-top" alt="Card image cap"
?>
<div class="col-1"></div>
<div class="col-4">
 <div class="card">
 	<?php echo'<img  class="card-img-top" id="pow" src="IMAGEM/'.$lista['id'].'/'.$lista['imagem'].'" /> ';?>
    <div class="card-body">
      <h5 class="card-title"><span class="evento"><?php echo "".$lista['Nome']."<br>";?></span></h5>
      <br>
      <img src="https://img.icons8.com/material-two-tone/16/000000/calendar--v1.png"/><label>Data:</label><?php echo " ".$lista['data']?>
      <p class="card-text"><img src="https://img.icons8.com/small/16/000000/clock.png"/><label>Hora:</label><?php echo " ".$lista['hora'] ?></p>
      <p class="card-text"><img src="https://img.icons8.com/officexs/16/000000/marker.png"/><label>Local</label>:<?php echo " ".$lista['local']; ?></p>

      <p class="card-text"><?php //echo nl2br("".$lista['descricao']."<br>");?></p>
      <p class="card-text"> 
      
     
      <div class="accordion" id="accordionExample">
  <div class="card1">
    <div class="card-header" id="headingOne">
      <h2 class="mb-0">
      	
        <button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
        Descrição
        </button>
   
      </h2>
    </div>

    <div id="collapseOne" class="collapse " aria-labelledby="headingOne" data-parent="#accordionExample">
      <div class="card-body">
      <p><?php echo nl2br("".$lista['descricao']."<br>"); ?></p>
      </div>
    </div>
  </div>
</div>  

      </p>
    </div>
</div>

<br><br>

</div>
<div class="col-1"></div>
 
 
<?php } ?>
</div>
<?php 


  $sql=$pdo->prepare("SELECT count(id) AS num_result FROM dadosevento");
  $sql->execute();
  $l = $sql->fetch(pdo::FETCH_ASSOC);

   $quantidade_pg= ceil($l['num_result']/$qtd_pagina);

   $max_links=2;
   ?> 
   <div class="pag">
   <?php
  ?><label class="ufa"><?php echo "<a href='eventos.php?pagina=1'> Primeira</a>";?></label><?php
    // echo "<button href='eventos.php?pagina=1'>Primeira</button";
   for ($pag_ant= $pagina - $max_links; $pag_ant <= $pagina -1 ; $pag_ant++) { 
      if ($pag_ant>=1) {   
   ?><label class="ufa"> <?php echo "<a href='eventos.php?pagina=$pag_ant'><span>$pag_ant</span></a>";?></label> <?php
        }
   }
     ?><label class="ufa"><?php echo "".$pagina;?></label><?php
   for ($pag_dep=$pagina + 1; $pag_dep <= $pagina + $max_links ; $pag_dep++) { 
      
       if ($pag_dep<=$quantidade_pg) {   
    ?><label class="ufa"> <?php  echo "<a href='eventos.php?pagina=$pag_dep'><span>$pag_dep</span></a>";?></label><?php
        }
   }

   ?><label class="ufa"><?php echo "<a href='eventos.php?pagina=$quantidade_pg'><span>Ultima</span></a>";?></label><?php
  
  
 ?>
</div>
<br>
<hr>
 <div class="col-sm-1" style="background-color: rgb(255,140,0,.08);"></div>
</div>
<div class="antes"></div>
<div id="rodape">
  <br><br><br>
   <div class="row">
    <div class="col-md-1"></div>
     <div class="col-md-2"><img src="logo_sizeP.jpg" style="" width="180px" class="rounded-circle"></div>
     <div class="col-md-2" id="info">
      <h5>Festa</h5>
      <p>Criar a minha</p>
      <p>Tudo certo</p>
      <p>Esta bem</p>
     </div>

     <div class="col-md-2" id="info">
      <h5>Perfil</h5>
      <p>Editar</p>
      <p>Configurar</p>
      <p>Restaurar</p>
     </div>
     <div class="col-md-2" id="info">
      <h5>Ajuda</h5>
      <p>Fale conosco</p>
      <p>Quero Premiun</p>
      <p>Classificar</p>
     </div>
     <div class="col-md-2" id="info">
      <h5>Social</h5>
      <p>Instagran</p>
      <p>Facebook</p>
      <p>Twitter</p>
     </div>
       </div>

</div>
    </script>


           <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
          <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js" integrity="sha384-UO2eT0CpHqdSJQ6hJty5KVphtPhzWj9WO1clHTMGa3JDZwrnQq4sF86dIHNDz0W1" crossorigin="anonymous"></script>
         <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js" integrity="sha384-JjSmVgyd0p3pXB1rRibZUAYoIIy6OrQ6VrjIEaFf/nJGzIxFDsf4x0xIM+B07jRM" crossorigin="anonymous"></script>
    
    

</body>
</html>