package IParty;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class Dados {

    
    public static void salvar(String arquivo, String conteudo, boolean adicionar) throws IOException{
    
    FileWriter fw = new FileWriter(arquivo, adicionar); //cria o arquivo txt
    fw.write(conteudo);
    fw.close();
    }

    public static String exibir(String arquivo) throws FileNotFoundException,IOException{
    
    File file = new File(arquivo);
    if(!file.exists()) return null;
     BufferedReader br = new BufferedReader(new FileReader(arquivo));
     String saida = "";
     String linha;
     while((linha = br.readLine()) != null)
     {
         saida += linha +"\n";
     }
     
     br.close();
     return saida;
    }
    
    public static boolean loginUsuario(String arquivo, String pesquisa) throws FileNotFoundException, IOException{
    
    File file = new File(arquivo);
    boolean retorno = false;
    if(!file.exists())
    {
        System.out.println("Arquivo não existe!");
        return retorno;
    }
    
    BufferedReader br = new BufferedReader(new FileReader(arquivo));
     String saida = "";
     String linha;
     while((linha = br.readLine()) != null)
     {
         System.out.println(linha);
         if(linha.equals(pesquisa)){  
             saida = br.readLine();
             retorno = true;
             break;
         }
         else{
             retorno = false;
         }
     }
     
     br.close();
     return retorno;//
    }
    
    public static boolean loginUsuarioSenha(String arquivo, String pesquisa) throws FileNotFoundException, IOException{
    
    File file = new File(arquivo);
    boolean retorno = false;
    if(!file.exists())
    {
        System.out.println("Arquivo não existe!");
        return retorno;
    }
    
    BufferedReader br = new BufferedReader(new FileReader(arquivo));
     String saida = "";
     String linha;
     while((linha = br.readLine()) != null)
     {
         System.out.println(linha);
         if(linha.equals(pesquisa)){  
             saida = linha+"\n"+br.readLine()+"\n"+br.readLine();
             retorno = true;
             break;
         }
         else{
             retorno = false;
         }
     }
     
     br.close();
     return retorno;//
    }
    
    public static String pesquisarEvento(String arquivo, String pesquisa) throws FileNotFoundException, IOException{
    
    File file = new File(arquivo);
    String retorno = null;
    if(!file.exists())
    {
        System.out.println("Arquivo não existe!");
        return retorno;
    }
    
    BufferedReader br = new BufferedReader(new FileReader(arquivo));
     String saida = "";
     String linha;
     while((linha = br.readLine()) != null)
     {
         System.out.println(linha);
         if(linha.equals(pesquisa)){  
             saida = linha+"\n"+br.readLine()+"\n"+br.readLine();
             retorno = saida;
             break;
         }
         else{
             retorno = "Evento não encontrado!";
         }
     }
     
     br.close();
     return retorno;
    }
    
    public static String pesquisarLocal(String arquivo, String pesquisa) throws FileNotFoundException, IOException{
    
    File file = new File(arquivo);
    String retorno = null;
    if(!file.exists())
    {
        System.out.println("Arquivo não existe!");
        return retorno;
    }
    
    BufferedReader br = new BufferedReader(new FileReader(arquivo));
     String saida = "";
     String linha;
     while((linha = br.readLine()) != null)
     {
         System.out.println(linha);
         if(linha.equals(pesquisa)){
             saida = linha+"\n"+br.readLine()+"\n"+br.readLine()+"\n"+br.readLine()+"\n"+br.readLine();
             retorno = saida;
             break;
             
         }
         else{
             retorno = "Local não encontrado!";
         }
     }
     
     br.close();
     return retorno;
    }
    
    public static String pesquisarArmazem(String arquivo, String pesquisa) throws FileNotFoundException, IOException{
    
    File file = new File(arquivo);
    String retorno = null;
    if(!file.exists())
    {
        System.out.println("Arquivo não existe!");
        return retorno;
    }
    
    BufferedReader br = new BufferedReader(new FileReader(arquivo));
     String saida = "";
     String linha;
     while((linha = br.readLine()) != null)
     {
         System.out.println(linha);
         if(linha.equals(pesquisa)){
             saida = linha+"\n"+br.readLine()+"\n"+br.readLine()+"\n"+br.readLine()+"\n"+br.readLine();
             retorno = saida;
             break;
         }
         else{
             retorno = "Armazém não encontrado!";
         }
     }
     
     br.close();
     return retorno;
    }
   }
