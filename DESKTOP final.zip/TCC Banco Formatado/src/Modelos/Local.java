package Modelos;


public class Local {
    
    private String nome;
    private String endereco;
    private int capacidadeMax;
    private String telefone;
    private String descricao;

    public Local(String nome, String endereco, int capacidadeMax, String telefone, String descricao) {
        this.nome = nome;
        this.endereco = endereco;
        this.capacidadeMax = capacidadeMax;
        this.telefone = telefone;
        this.descricao = descricao;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public String getEndereco() {
        return endereco;
    }

    public void setEndereco(String endereco) {
        this.endereco = endereco;
    }

    public int getCapacidadeMax() {
        return capacidadeMax;
    }

    public void setCapacidadeMax(int capacidadeMax) {
        this.capacidadeMax = capacidadeMax;
    }

    public String getTelefone() {
        return telefone;
    }

    public void setTelefone(String telefone) {
        this.telefone = telefone;
    }

    public String getDescricao() {
        return descricao;
    }

    public void setDescricao(String descricao) {
        this.descricao = descricao;
    }
    
    
    
}
